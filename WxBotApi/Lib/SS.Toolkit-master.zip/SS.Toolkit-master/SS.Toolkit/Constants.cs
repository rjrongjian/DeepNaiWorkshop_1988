﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SS.Toolkit
{
    class Constants
    {
        public const string DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
        public const string DATE_TIME_MS_FORMAT = "yyyy-MM-dd HH:mm:ss.fff";
    }
}
