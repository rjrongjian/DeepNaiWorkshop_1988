﻿using System.Collections.Generic;

namespace SS.Toolkit.IO
{
    /// <summary>
    /// Class to store one CSV row
    /// </summary>
    public class CsvRow : List<string>
    {
        public string LineText { get; set; }
    }
}
